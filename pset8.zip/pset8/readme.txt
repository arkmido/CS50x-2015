changelog:

	**changed constants.php USERNAME = "root"; PASSWORD = ""

	**created php.ini file to C:\Windows to load a PHP extension for mysql
		this is used for the import.php and functions.php to enable mysql query using php cgi...

	**changed require(__DIR__ . "/path/") for windows